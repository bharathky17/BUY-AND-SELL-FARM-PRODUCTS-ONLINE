package project.fifthforce.finalsecond;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class sellerprofile extends AppCompatActivity {
    DBHelper gm;
    Button btn;
    EditText name,address;
    String s1,s2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sellerprofile);
        gm=new DBHelper(sellerprofile.this);
        btn=(Button)findViewById(R.id.btn69);
        name=(EditText)findViewById(R.id.name69);
        address=(EditText)findViewById(R.id.address69);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                s1=name.getText().toString();
                s2=address.getText().toString();
                int n=gm.getdata1().getCount();
                if(n==0){
                    gm.insertData1(s1,s2);
                    Toast.makeText(sellerprofile.this, "INSERTED SUCCESSFULLY", Toast.LENGTH_SHORT).show();
                }else{
                    gm.updateData(s1,s2);
                    Toast.makeText(sellerprofile.this, "UPDATED SUCCESSFULLY", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}