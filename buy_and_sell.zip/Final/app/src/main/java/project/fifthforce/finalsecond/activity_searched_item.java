package project.fifthforce.finalsecond;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class activity_searched_item extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_searched_item);

        TextView Selected =(TextView)findViewById(R.id.selected_item);
        TextView Type1=findViewById(R.id.Type1);
        TextView Type2=findViewById(R.id.Type2);
        TextView Type3=findViewById(R.id.Type3);

        Bundle extras = getIntent().getExtras();
        String tmp = extras.getString("pos");

        if(tmp.equals("0")){
            Selected.setText("Vegetables");
        }
        if(tmp.equals("1")){

            Selected.setText("Cereals");
        }
        if(tmp.equals("2")){

            Selected.setText("Pulses");
        }

        if(Selected.getText().equals("Vegetables")){
            Type1.setText("Onions");
            Type2.setText("Potatoes");
            Type3.setText("Tomatoes");
        }
        if(Selected.getText().equals("Cereals"))
        {
            Type1.setText("Wheat");
            Type2.setText("Rice");
            Type3.setText("Maize");
        }
        if(Selected.getText().equals("Pulses"))
        {
            Type1.setText("Kidney Beans");
            Type2.setText("Chick Peas");
            Type3.setText("Lentils");
        }
    }
    public void openShop(View view)
    {
        ImageView imageView = (ImageView) view;
        Intent intent = new Intent(this,VirtualShop.class);
        startActivity(intent);

    }
}