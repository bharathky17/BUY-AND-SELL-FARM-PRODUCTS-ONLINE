package project.fifthforce.finalsecond;

public class logindb {
    private int id;
    private String phone_number;
    private String password;
    private String type;

    public logindb(int id, String phone_number, String password, String type) {
        this.id = id;
        this.phone_number = phone_number;
        this.password = password;
        this.type = type;
    }
    public logindb(String phone_number, String password, String type) {
        this.phone_number = phone_number;
        this.password = password;
        this.type = type;
    }
    public logindb() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
