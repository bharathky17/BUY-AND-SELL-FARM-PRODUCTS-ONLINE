package project.fifthforce.finalsecond;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


public class home extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        TextView vegImg1Text1=findViewById(R.id.vegImg1Text1);
        TextView vegImg1Text2=findViewById(R.id.vegImg1Text2);
        TextView vegImg2Text1=findViewById(R.id.vegImg2Text1);
        TextView vegImg2Text2=findViewById(R.id.vegImg2Text2);
        TextView vegImg3Text1=findViewById(R.id.vegImg3Text1);
        TextView vegImg3Text2=findViewById(R.id.vegImg3Text2);
        TextView cerealsImg1Text1=findViewById(R.id.cerealsImg1Text1);
        TextView cerealsImg1Text2=findViewById(R.id.cerealsImg1Text2);
        TextView cerealsImg2Text1=findViewById(R.id.cerealsImg2Text1);
        TextView cerealsImg2Text2=findViewById(R.id.cerealsImg2Text2);
        TextView cerealsImg3Text1=findViewById(R.id.cerealsImg3Text1);
        TextView cerealsImg3Text2=findViewById(R.id.cerealsImg3Text2);
        TextView pulsesImg1Text1=findViewById(R.id.pulsesImg1Text1);
        TextView pulsesImg1Text2=findViewById(R.id.pulsesImg1Text2);
        TextView pulsesImg2Text1=findViewById(R.id.pulsesImg2Text1);
        TextView pulsesImg2Text2=findViewById(R.id.pulsesImg2Text2);
        TextView pulsesImg3Text1=findViewById(R.id.pulsesImg3Text1);
        TextView pulsesImg3Text2=findViewById(R.id.pulsesImg3Text2);

        vegImg1Text1.setText("POTATOES");
        vegImg1Text2.setText("Rs.38");
        vegImg2Text1.setText("ONIONS");
        vegImg2Text2.setText("Rs.22");
        vegImg3Text1.setText("TOMATOES");
        vegImg3Text2.setText("Rs.40");
        cerealsImg1Text1.setText("RICE");
        cerealsImg1Text2.setText("Rs.40");
        cerealsImg2Text1.setText("MAIZE");
        cerealsImg2Text2.setText("Rs.20");
        cerealsImg3Text1.setText("WHEAT");
        cerealsImg3Text2.setText("Rs.20");
        pulsesImg1Text1.setText("LENTILS");
        pulsesImg1Text2.setText("Rs.50");
        pulsesImg2Text1.setText("KIDNEY BEANS");
        pulsesImg2Text2.setText("Rs.100");
        pulsesImg3Text1.setText("CHICK BEANS");
        pulsesImg3Text2.setText("Rs.30");

        Button b = (Button)findViewById(R.id.searchButton);
        b.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Intent intent = new Intent(home.this, Search.class);
                startActivity(intent);
            }
        });

    }


    public void openShopveg1(View view)
    {
        params.SELLER_LOCATION="Roper,Punjab";
        params.SELLER_NAME="Dilbar Singh";
        params.SELLER_NUMBER="9421325415";
        ImageView imageView = (ImageView) view;
        Intent intent = new Intent(this,VirtualShop.class);
        startActivity(intent);

    } public void openShopveg2(View view)
    {
        params.SELLER_LOCATION="Roper,Punjab";
        params.SELLER_NAME="Dilbar Singh";
        params.SELLER_NUMBER="9421325415";
        ImageView imageView = (ImageView) view;
        Intent intent = new Intent(this,VirtualShop.class);
        startActivity(intent);

    } public void openShopveg3(View view)
    {
        params.SELLER_LOCATION="Palwal,Haryana";
        params.SELLER_NAME="Lal Das";
        params.SELLER_NUMBER="9852265463";
        ImageView imageView = (ImageView) view;
        Intent intent = new Intent(this,VirtualShop.class);
        startActivity(intent);

    } public void openShopcereals1(View view)
    {
        params.SELLER_LOCATION="Ajmer,Rajasthan";
        params.SELLER_NAME="Babu Roi";
        params.SELLER_NUMBER="9210044456";
        ImageView imageView = (ImageView) view;
        Intent intent = new Intent(this,VirtualShop.class);
        startActivity(intent);

    } public void openShopcereals2(View view)
    {
        params.SELLER_LOCATION="Ajmer,Rajasthan";
        params.SELLER_NAME="Babu Roi";
        params.SELLER_NUMBER="9210044456";
        ImageView imageView = (ImageView) view;
        Intent intent = new Intent(this,VirtualShop.class);
        startActivity(intent);

    } public void openShopcereals3(View view)
    {
        params.SELLER_LOCATION="Palwal,Haryana";
        params.SELLER_NAME="Lal Das";
        params.SELLER_NUMBER="9852265463";
        ImageView imageView = (ImageView) view;
        Intent intent = new Intent(this,VirtualShop.class);
        startActivity(intent);

    } public void openShoppulses1(View view)
    {
        params.SELLER_LOCATION="Roper,Punjab";
        params.SELLER_NAME="Dilbar Singh";
        params.SELLER_NUMBER="9421325415";
        ImageView imageView = (ImageView) view;
        Intent intent = new Intent(this,VirtualShop.class);
        startActivity(intent);

    } public void openShoppulses2(View view)
    {
        params.SELLER_LOCATION="Palwal,Haryana";
        params.SELLER_NAME="Lal Das";
        params.SELLER_NUMBER="9852265463";
        ImageView imageView = (ImageView) view;
        Intent intent = new Intent(this,VirtualShop.class);
        startActivity(intent);

    } public void openShoppulses3(View view)
    {
        params.SELLER_LOCATION="Ajmer,Rajasthan";
        params.SELLER_NAME="Babu Roi";
        params.SELLER_NUMBER="9210044456";
        ImageView imageView = (ImageView) view;
        Intent intent = new Intent(this,VirtualShop.class);
        startActivity(intent);

    }







}