package project.fifthforce.finalsecond;

public class params {
    public static final int DB_VERSION = 1;
    public static final String DB_NAME = "users";
    public static final String TABLE_NAME = "login";


    //Keys of our table in db
    public static final String KEY_ID = "id";
    public static final String KEY_PHONE = "phone_number";
    public static final String KEY_PASS = "password";
    public static final String KEY_TYPE = "type";
    public static  String KEY_TYPE1=null;
    public static  String LOGIN_USER=null;
    public static  int LOGIN_ID=0;

    public static String SELLER_NAME=null;
    public static String SELLER_LOCATION=null;
    public static String SELLER_NUMBER=null;

}
