package project.fifthforce.finalsecond;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class VirtualShop extends AppCompatActivity {
    public void print(String location,String name,String number) {


        TextView sellerLocation = findViewById(R.id.sellerLocation);
        sellerLocation.setText(location);
        TextView sellerName = findViewById(R.id.sellerName);
        sellerName.setText(name);
        TextView sellerNumber = findViewById(R.id.sellerNumber);
        sellerNumber.setText(number);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_virtual_shop);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);//back button but not working only showing
        print(params.SELLER_LOCATION,params.SELLER_NAME,params.SELLER_NUMBER);

    }

}