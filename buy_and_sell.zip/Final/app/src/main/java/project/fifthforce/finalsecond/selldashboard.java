package project.fifthforce.finalsecond;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.List;

public class selldashboard extends AppCompatActivity {

    ImageButton accessprofile, accessmyads, addnewad;
    DBHelper DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selldashboard);
        DB = new DBHelper(this);
        addnewad=(ImageButton)findViewById(R.id.addnewad);
        addnewad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user=getIntent().getStringExtra("user");
                Intent i=new Intent(selldashboard.this,createad.class);
                i.putExtra("user",user);
                startActivity(i);
            }
        });
        accessprofile = (ImageButton) findViewById(R.id.accessprofile);
        accessprofile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(selldashboard.this, "Clicked on Profile", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), sellerprofile.class);
                startActivity(intent);

            }
        });
        accessmyads=(ImageButton) findViewById(R.id.accessmyads);
        accessmyads.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user=getIntent().getStringExtra("user");
                Intent intent = new Intent(getApplicationContext(),myad1.class);
                intent.putExtra("user",user);
                startActivity(intent);
            }
        }));
        List<logindb> login_id = DB.login_id();
        for (logindb contact : login_id) {
            params.LOGIN_ID=contact.getId();
        }
       Log.d("dblogin", "\nId: " +params.LOGIN_ID );

    }


}